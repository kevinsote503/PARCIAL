﻿using System;
using System.Windows.Forms;

namespace PARCIAL
{
    public partial class Form1 : Form
    {
        // Matriz: {Desde, Hasta, Precio, Adicional}
        static double[,] tablaImpuestos = new double[,]
        {
            {0.01,       500,        1.5, 0},
            {500.01,     1000,       1.5, 3},
            {1000.01,    2000,       3,   3},
            {2000.01,    3000,       6,   3},
            {3000.01,    6000,       9,   2},
            {8000.01,    18000,      15,  2},
            {18000.01,   30000,      39,  2},
            {30000.01,   60000,      63,  1},
            {60000.01,   100000,     93,  0.8},
            {100000.01,  200000,     125, 0.7},
            {200000.01,  300000,     195, 0.6},
            {300000.01,  400000,     255, 0.45},
            {400000.01,  500000,     300, 0.4},
            {500000.01,  1000000,    340, 0.30},
            {1000000.01, 99999999,   490, 0.18}
        };

        public Form1()
        {
            InitializeComponent();
        }

        static double CalcularImpuesto(double monto)
        {
            for (int i = 0; i < tablaImpuestos.GetLength(0); i++)
            {
                double desde = tablaImpuestos[i, 0];
                double hasta = tablaImpuestos[i, 1];
                double precio = tablaImpuestos[i, 2];
                double adicional = tablaImpuestos[i, 3];

                if (monto >= desde && monto <= hasta)
                {
                    double impuesto = ((monto - desde) / 1000) * adicional + precio;
                    return Math.Round(impuesto, 2);
                }
            }
            return -1;
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMonto.Text))
            {
                MessageBox.Show("Ingrese un monto antes de calcular.", "Campo vacío",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!double.TryParse(txtMonto.Text, out double monto) || monto <= 0)
            {
                MessageBox.Show("Ingrese un monto numérico válido y mayor a cero.", "Dato inválido",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            double resultado = CalcularImpuesto(monto);

            if (resultado >= 0)
                lblResultado.Text = $"Impuesto a pagar: ${resultado}";
            else
                lblResultado.Text = "Monto fuera de los rangos establecidos.";
        }

        private void txtMonto_TextChanged(object sender, EventArgs e)
        {
            lblResultado.Text = "";
        }
    }
}